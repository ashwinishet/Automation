/**
 * 
 */
package main.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.pom.BranchCreationPage;
import main.pom.BranchDetailsPage;
import main.pom.BranchLandingPage;
import main.pom.HomePage;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class BranchTest extends BaseTest {
	HomePage homePage;
	BranchLandingPage branchHomePg;
	BranchCreationPage branchPg;
	BranchDetailsPage branchDetailsPg;

	@Test(priority = 1)
	public void testBranchAdd() {
		applogger.info("Starting Branch Creation Test ");
		homePage = new HomePage();
		homePage.entitiesDropdownClick();
		branchHomePg = homePage.branchesLinkClick();
		branchPg = branchHomePg.createBranchButtonClick();
		branchPg.createBranch(CONFIG.getProperty("bName1"), CONFIG.getProperty("bCode1"));
		CommonCode.shortWait();
		branchPg = branchHomePg.createBranchButtonClick();
		branchPg.createBranch(CONFIG.getProperty("bName2"), CONFIG.getProperty("bCode2"));
	}

	@Test(priority = 2)
	public void testSearchBranch() {
		applogger.info("Starting Search Branch Test");
		branchHomePg = new BranchLandingPage();
		CommonCode.shortWait();
		branchHomePg.searchBranch(CONFIG.getProperty("bName1"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
	}

	@Test(priority = 3)
	public void testEditBranch() {
		applogger.info("Starting Edit Search Branch Test");
		CommonCode.shortWait();
		branchHomePg.searchBranch(CONFIG.getProperty("bName1"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
		branchHomePg.editBranch(CONFIG.getProperty("bNameNew"), CONFIG.getProperty("bCodeNew"));
	}

	@Test(priority = 4)
	public void testViewBranch() {
		applogger.info("Starting View Search Branch Test");
		branchHomePg = new BranchLandingPage();
		CommonCode.shortWait();
		branchHomePg.searchBranch(CONFIG.getProperty("bName2"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
		branchDetailsPg = branchHomePg.viewBranch();
		Assert.assertEquals(branchDetailsPg.getBranchCode(), CONFIG.getProperty("bCode2"));
		Assert.assertEquals(branchDetailsPg.getBranchName(), CONFIG.getProperty("bName2"));
		branchDetailsPg.navigateBack();
	}

	@Test(priority = 5)
	public void testDeleteBranch() {
		applogger.info("Starting Delete Search Branch Test");
		branchHomePg = new BranchLandingPage();
		branchHomePg.searchBranch(CONFIG.getProperty("bName2"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
		branchHomePg.deleteBranch();
	}

	@Test(priority = 6)
	public void testLogout() {
		applogger.info("Logging out from the Application ");
		homePage = new HomePage();
		CommonCode.shortWait();
		homePage.logout();
	}
}
