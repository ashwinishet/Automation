/**
 * 
 */
package main.test;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import main.pom.HomePage;
import main.pom.SettingsPage;

/**
 * @author Ashwini_Shet
 *
 */
public class SettingTest extends BaseTest {
	HomePage homePage;
	SettingsPage settingPage;

	@Parameters({ "firstname", "lastname", "email" })
	@Test(priority = 1)
	public void testEditAccountSettings(String firstName, String lastName, String email) {
		applogger.info("Starting Settings Edit Test ");
		homePage = new HomePage();
		homePage.accountDropdownClick();
		settingPage = homePage.settingsLinkClick();
		settingPage.editFirstName(firstName);
		settingPage.editLastName(lastName);
		settingPage.editEmail(email);
		boolean settingSaved = settingPage.saveSettingChanges();
		if (settingSaved)
			applogger.info("Settings edited successfully");
		else
			applogger.info("Error while editing the settings");
		Assert.assertFalse(settingSaved);
	}
}
