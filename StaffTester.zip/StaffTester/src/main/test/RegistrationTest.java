/**
 * 
 */
package main.test;

import static org.testng.Assert.assertFalse;

import org.testng.annotations.Test;

import main.pom.RegistrationPage;

/**
 * @author Ashwini_Shet
 *
 */
public class RegistrationTest extends BaseTest {

	@Test
	public void registerNewUser() {
		applogger.info("Starting Register New User Test");
		RegistrationPage regPg = new RegistrationPage();
		boolean successValue = regPg.registerNewUser();
		if (successValue)
			applogger.info("Registration unsuccessful");
		else
			applogger.info("Registration successful");
		assertFalse(successValue);
	}
}
