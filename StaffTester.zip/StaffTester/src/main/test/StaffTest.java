/**
 * 
 */
package main.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.pom.HomePage;
import main.pom.LoginPage;
import main.pom.StaffCreationPage;
import main.pom.StaffDetailsPage;
import main.pom.StaffLandingPage;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class StaffTest extends BaseTest {
	LoginPage loginPg;
	HomePage homePage;
	StaffCreationPage staffCreationPage;
	StaffDetailsPage staffDetailPage;
	StaffLandingPage staffHomePage;

	@Test(priority = 1)
	public void testStaffAdd() {
		applogger.info("Starting Staff Creation Test");
		loginPg = new LoginPage();
		homePage = loginPg.login(CONFIG.getProperty("username"), CONFIG.getProperty("password"));
		homePage = new HomePage();
		homePage.entitiesDropdownClick();
		staffHomePage = homePage.staffLinkClick();
		;
		staffCreationPage = staffHomePage.createStaffButtonClick();
		staffCreationPage.createStaff(CONFIG.getProperty("StaffName1"), CONFIG.getProperty("StaffBName1"));
	}

	@Test(priority = 2)
	public void testSearchStaff() {
		applogger.info("Starting Search Staff Test");
		staffHomePage = new StaffLandingPage();
		CommonCode.shortWait();
		staffHomePage.searchStaffwithValidation(CONFIG.getProperty("StaffName1"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
	}

	@Test(priority = 3)
	public void testEditStaff() {
		applogger.info("Starting Edit Staff Test");
		staffHomePage = new StaffLandingPage();
		CommonCode.shortWait();
		staffHomePage.searchStaff(CONFIG.getProperty("StaffName1"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
		staffHomePage.editStaff(CONFIG.getProperty("StaffName2"));
	}

	@Test(priority = 4)
	public void testViewStaff() {
		applogger.info("Starting View Staff Test");
		staffHomePage = new StaffLandingPage();
		CommonCode.shortWait();
		staffHomePage.searchStaff(CONFIG.getProperty("StaffName2"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
		staffDetailPage = staffHomePage.viewStaff();
		Assert.assertEquals(staffDetailPage.getBranchName(), CONFIG.getProperty("StaffBName1"));
		Assert.assertEquals(staffDetailPage.getStaffName(), CONFIG.getProperty("StaffName2"));
		staffDetailPage.navigateBack();
	}

	@Test(priority = 5)
	public void testDeleteStaff() {
		applogger.info("Starting Delete Staff Test");
		staffHomePage = new StaffLandingPage();
		staffHomePage.searchStaff(CONFIG.getProperty("StaffName2"));
		Integer numberRows = CommonCode.getNumberRows(driver);
		Assert.assertEquals(numberRows, Integer.valueOf(CONFIG.getProperty("expectedCount")));
		staffHomePage.deleteStaff();
	}
}
