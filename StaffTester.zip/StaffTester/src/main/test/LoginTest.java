
package main.test;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import main.pom.HomePage;
import main.pom.LoginPage;

/**
 * @author Ashwini_Shet
 *
 */
public class LoginTest extends BaseTest {
	LoginPage loginPg;
	HomePage homePg;
	String FilePath;
	Properties data;
	String workingDir;
	String input;

	@Parameters({"username", "pwd"})
	@Test(priority = 1)
	public void testLogin(String userName,String password) {
		applogger.info("Started Login Test");
		loginPg = new LoginPage();
		homePg = loginPg.login(userName,password);
		boolean returnValue = homePg.loginsuccessfull();
		assertTrue(returnValue);
		if(returnValue)
			applogger.info("Login Successful");
	}
}
