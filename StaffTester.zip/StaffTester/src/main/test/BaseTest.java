package main.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTest {

	public static WebDriver driver;
	public String WEBSITE = "http://127.0.0.1:8080";
	public static Properties CONFIG = null;
	public static Logger applogger = null;

	@BeforeTest
	public void LaunchBrowserwithURL() {
		String log4jConfpath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfpath);
		File file = new File(System.getProperty("user.dir") + "\\src\\main\\resources\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		driver = new ChromeDriver();
		driver.navigate().to(WEBSITE);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if (CONFIG == null) {
			CONFIG = new Properties();
			FileInputStream fn = null;
			try {
				fn = new FileInputStream(System.getProperty("user.dir") + "\\src\\main\\resources\\Data.properties");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			try {
				CONFIG.load(fn);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (applogger == null) {
			System.out.println("Intializing the logger");
			applogger = Logger.getLogger("Automation Logs");
		}

	}

	@AfterTest
	protected void CloseBrowser() {
		applogger.info("Closing the browser");
		driver.close();
		driver.quit();
	}

	@AfterMethod
	public void screenShot(ITestResult result) {
		if (ITestResult.FAILURE == result.getStatus()) {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(scrFile,
						new File(System.getProperty("user.dir") + "\\Screenshots\\" + result.getName() + ".png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}
