/**
 * 
 */
package main.test;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import main.pom.HomePage;
import main.pom.PasswordPage;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class PasswordTest extends BaseTest {
	HomePage homePage;
	PasswordPage passwordPage;

	@Parameters({ "newPassword" })
	@Test(priority = 1)
	public void testPasswordEdit(String pwd) {
		applogger.info("Starting Password Edit Test ");
		homePage = new HomePage();
		homePage.accountDropdownClick();
		passwordPage = homePage.passwordLinkClick();
		boolean passwordChanged = passwordPage.savePasswordChanges(pwd);
		if (passwordChanged)
			applogger.info("Settings edited successfully");
		else
			applogger.info("Error while editing the settings");
		Assert.assertFalse(passwordChanged);
	}
}
