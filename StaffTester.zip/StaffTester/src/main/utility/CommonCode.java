/**
 * 
 */
package main.utility;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import main.test.BaseTest;

/**
 * @author Ashwini_Shet
 *
 */
public class CommonCode extends BaseTest {

	public static void refresh(WebDriver driver) {
		applogger.info("Refreshing the Page");
		driver.navigate().refresh();
	}

	public static void selectFromDropDown(WebElement wb, String text) {
		Select dropdown = new Select(wb);
		dropdown.selectByVisibleText(text);
		applogger.info("Selected value from the Dropdown : " + text);
	}

	public static void waitForElementLoad(WebDriver driver, WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, Integer.parseInt(CONFIG.getProperty("Short")));
		wait.until(ExpectedConditions.elementToBeClickable(webElement));
	}

	public static void clickElement(WebDriver driver, WebElement webElement) {
		waitForElementLoad(driver, webElement);
		webElement.click();
	}

	public static void waitTillElementDisplayed(WebDriver driver, WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, Integer.parseInt(CONFIG.getProperty("Short")));
		wait.until(ExpectedConditions.visibilityOf(webElement));
	}

	public static Integer getNumberRows(WebDriver driver) {
		int count = 0;
		List<WebElement> rows = driver.findElements(By.xpath("//table // tr"));
		count = rows.size();
		applogger.info("Getting count of rows from the table ");
		if (count > 1)
			return count - 1;
		else
			return 0;
	}

	public static boolean verifyTextPresentForWebElement(WebDriver driver, WebElement webElement) {
		boolean elementPresent = false;
		waitTillElementDisplayed(driver, webElement);
		if (webElement.getText() == null || webElement.getText().equalsIgnoreCase("")
				|| webElement.getText().isEmpty()) {
			applogger.info("Text is  not  present in the page ");
			return elementPresent;
		} else
			applogger.info("Text is  present in the page ");
		return true;
	}

	public static void shortWait() {
		try {
			Thread.sleep(Integer.parseInt(CONFIG.getProperty("Short")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
