
package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class StaffDetailsPage extends BaseTest {

	public StaffDetailsPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "tr:nth-of-type(1) td:nth-of-type(2) input")
	WebElement staffNameValue;

	@FindBy(css = "tr:nth-of-type(2) td:nth-of-type(2) input")
	WebElement branchNameValue;

	@FindBy(css = "button[type='submit']")
	WebElement backButton;

	public StaffLandingPage navigateBack() {
		CommonCode.clickElement(driver, backButton);
		return new StaffLandingPage();
	}

	public String getBranchName() {
		return branchNameValue.getAttribute("value");
	}

	public String getStaffName() {
		return staffNameValue.getAttribute("value");
	}
}
