/**
 * 
 */
package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class SettingsPage extends BaseTest{

	public SettingsPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css = "input[ng-model='settingsAccount.firstName']")
	WebElement firstName;
	
	@FindBy(css = "input[ng-model='settingsAccount.lastName']")
	WebElement lastName;
	
	@FindBy(css = "input[ng-model='settingsAccount.email']")
	WebElement emailID;
	
	@FindBy(css = "input[ng-model='settingsAccount.langKey']")
	WebElement language;
	
	@FindBy(css = "button[translate='settings.form.button']")
	WebElement save;
	
	@FindBy(css = "[translate='settings.messages.error.fail']")
	WebElement unsuccessfulMessage;
	
	public void editFirstName(String userName) {
		CommonCode.waitForElementLoad(driver, firstName);
		firstName.clear();
		firstName.sendKeys(userName);
	}
	
	public void editLastName(String lastname) {
		CommonCode.waitForElementLoad(driver, lastName);
		lastName.clear();
		lastName.sendKeys(lastname);
	}
	
	public void editEmail(String email) {
		CommonCode.waitForElementLoad(driver, emailID);
		lastName.clear();
		lastName.sendKeys(email);
	}
	
	public void selectLanguage(String lang){
		language.sendKeys(lang);
	}
	
	public boolean saveSettingChanges() {
		CommonCode.clickElement(driver, save);
		CommonCode.waitForElementLoad(driver, unsuccessfulMessage);
		return unsuccessfulMessage.isDisplayed();
	}
	
	
}
