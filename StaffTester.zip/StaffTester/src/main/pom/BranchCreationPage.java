package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class BranchCreationPage extends BaseTest {

	@FindBy(css = "input[ng-model='branch.name']")
	WebElement branchName;

	@FindBy(css = "input[ng-model='branch.code']")
	WebElement branchCode;

	@FindBy(css = "span[translate='entity.action.save']")
	WebElement branchSave;

	BranchCreationPage() {
		PageFactory.initElements(driver, this);
	}

	public void createBranch(String branchNa, String branchID) {
		CommonCode.waitTillElementDisplayed(driver, branchName);
		CommonCode.waitTillElementDisplayed(driver, branchCode);
		applogger.info("Creating new Branch with Branch name : " + branchNa + "And Branch Code : " + branchID);
		branchName.sendKeys(branchNa);
		branchCode.sendKeys(branchID);
		CommonCode.clickElement(driver, branchSave);
	}

	public void editBranch(String newBranchNa, String newBranchID) {
		CommonCode.waitTillElementDisplayed(driver, branchName);
		CommonCode.waitTillElementDisplayed(driver, branchCode);
		applogger.info("Editing Branch with Branch name : " + newBranchNa + "And Branch Code : " + newBranchID);
		branchName.clear();
		branchCode.clear();
		createBranch(newBranchNa, newBranchID);
	}
}
