package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class HomePage extends BaseTest {

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "div[translate='main.logged.message']")
	WebElement loginMessage;

	@FindBy(css = "span[translate='global.menu.entities.main']")
	WebElement entities;

	@FindBy(css = "span[translate='global.menu.entities.branch']")
	WebElement branch;

	@FindBy(css = "span[translate='global.menu.entities.staff']")
	WebElement staff;

	@FindBy(css = "span[translate='global.menu.account.main']")
	WebElement account;

	@FindBy(css = "span[translate='global.menu.account.settings']")
	WebElement settings;

	@FindBy(css = "span[translate='global.menu.account.sessions']")
	WebElement session;

	@FindBy(css = "span[translate='global.menu.account.password']")
	WebElement password;

	@FindBy(css = "span[translate='global.menu.account.logout']")
	WebElement logout;

	public void logout() {
		applogger.info("User initiated Logout");
		CommonCode.clickElement(driver, account);
		CommonCode.clickElement(driver, logout);
	}

	public boolean loginsuccessfull() {
		CommonCode.waitTillElementDisplayed(driver, loginMessage);
		applogger.info("Valid User Logged in");
		return loginMessage.isDisplayed();
	}

	public void entitiesDropdownClick() {
		applogger.info("Entities Clicked");
		CommonCode.clickElement(driver, entities);
	}

	public BranchLandingPage branchesLinkClick() {
		applogger.info("Branch Option selected");
		CommonCode.clickElement(driver, branch);
		return new BranchLandingPage();
	}

	public StaffLandingPage staffLinkClick() {
		applogger.info("Staff Option selected");
		CommonCode.clickElement(driver, staff);
		return new StaffLandingPage();
	}

	public void accountDropdownClick() {
		applogger.info("Account Clicked");
		CommonCode.clickElement(driver, account);
	}

	public SettingsPage settingsLinkClick() {
		applogger.info("Settings Option selected");
		CommonCode.clickElement(driver, settings);
		return new SettingsPage();
	}

	public void sessionLinkClick() {
		applogger.info("Session Option selected");
		CommonCode.clickElement(driver, session);
	}
	
	public PasswordPage passwordLinkClick() {
		applogger.info("Password Option selected");
		CommonCode.clickElement(driver, password);
		return new PasswordPage();
	}

}
