package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class LoginPage extends BaseTest {

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "username")
	WebElement username;

	@FindBy(id = "password")
	WebElement password;

	@FindBy(css = "button.btn.btn-primary.ng-scope")
	WebElement authenticateButton;

	@FindBy(xpath = "//a[text()='login']")
	WebElement loginLink;

	@FindBy(xpath = "//a[text()='Register a new account']")
	WebElement registerLink;

	public HomePage login(String userName, String passWord) {
		applogger.info("Logging in");
		CommonCode.clickElement(driver, loginLink);
		CommonCode.waitTillElementDisplayed(driver, username);
		applogger.info("User Name used : " + userName);
		CommonCode.waitTillElementDisplayed(driver, password);
		applogger.info("Password used : " + passWord);
		username.sendKeys(userName);
		password.sendKeys(passWord);
		CommonCode.clickElement(driver, authenticateButton);
		applogger.info("Logged In as " + userName);
		return new HomePage();
	}

	public void registerNewUser() {
		applogger.info("Registering New User");
		CommonCode.clickElement(driver, registerLink);
	}
}
