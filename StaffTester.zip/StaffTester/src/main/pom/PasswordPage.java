/**
 * 
 */
package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class PasswordPage extends BaseTest {

	public PasswordPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "input[ng-model='password']")
	WebElement newPassword;

	@FindBy(css = "input[ng-model='confirmPassword']")
	WebElement confirmNewPassword;

	@FindBy(css = "button[translate='password.form.button']")
	WebElement save;

	@FindBy(css = "[translate='password.messages.error']")
	WebElement unsuccessfulMessage;
	
	@FindBy(css = "[translate='global.messages.error.dontmatch']")
	WebElement passwordDoNotMatchMessgae;

	public boolean savePasswordChanges(String newPwd) {
		CommonCode.waitForElementLoad(driver, newPassword);
		CommonCode.waitForElementLoad(driver, confirmNewPassword);
		newPassword.clear();
		confirmNewPassword.clear();
		newPassword.sendKeys(newPwd);
		confirmNewPassword.sendKeys(newPwd);
		CommonCode.clickElement(driver, save);
		CommonCode.waitForElementLoad(driver, unsuccessfulMessage);
		return unsuccessfulMessage.isDisplayed();
	}
	
	public boolean savePasswordChanges(String newPwd, String confirmPwdNotMatching) {
		CommonCode.waitForElementLoad(driver, newPassword);
		CommonCode.waitForElementLoad(driver, confirmNewPassword);
		newPassword.clear();
		confirmNewPassword.clear();
		newPassword.sendKeys(newPwd);
		confirmNewPassword.sendKeys(confirmPwdNotMatching);
		CommonCode.waitForElementLoad(driver, passwordDoNotMatchMessgae);
		return passwordDoNotMatchMessgae.isDisplayed();
	}
	}

