/**
 * 
 */
package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class RegistrationPage extends BaseTest {

	@FindBy(css = "input[placeholder='Your login']")
	WebElement loginTextBox;

	@FindBy(css = "input[placeholder='Your e-mail']")
	WebElement emailTextBox;

	@FindBy(css = "input[placeholder='New password']")
	WebElement passwordTextBox;

	@FindBy(css = "input[placeholder='Confirm the new password']")
	WebElement confirmPasswordTextBox;

	@FindBy(css = "[translate='register.form.button']")
	WebElement registerButton;

	@FindBy(css = "[translate='global.messages.info.register']")
	WebElement registerhyperLink;

	@FindBy(css = "[translate='register.messages.error.fail']")
	WebElement unsuccessfullMessage;

	public RegistrationPage() {
		PageFactory.initElements(driver, this);
	}

	public boolean registerNewUser() {
		applogger.info("Registering New User");
		CommonCode.clickElement(driver, registerhyperLink);
		CommonCode.waitTillElementDisplayed(driver, loginTextBox);
		CommonCode.waitTillElementDisplayed(driver, emailTextBox);
		CommonCode.waitTillElementDisplayed(driver, passwordTextBox);
		CommonCode.waitTillElementDisplayed(driver, confirmPasswordTextBox);
		applogger.info("Name is : " + CONFIG.getProperty("newUserName"));
		loginTextBox.sendKeys(CONFIG.getProperty("newUserName"));
		applogger.info("Email is : " + CONFIG.getProperty("emailID"));
		emailTextBox.sendKeys(CONFIG.getProperty("emailID"));
		applogger.info("PassWord is : " + CONFIG.getProperty("newPassword"));
		passwordTextBox.sendKeys(CONFIG.getProperty("newPassword"));
		confirmPasswordTextBox.sendKeys(CONFIG.getProperty("newPassword"));
		CommonCode.clickElement(driver, registerButton);
		CommonCode.waitTillElementDisplayed(driver, unsuccessfullMessage);
		return unsuccessfullMessage.isDisplayed();
	}
}
