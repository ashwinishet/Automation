
package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class StaffCreationPage extends BaseTest {

	public StaffCreationPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "input[ng-model='staff.name']")
	WebElement staffName;

	@FindBy(css = "select[ng-model='staff.related_branchId']")
	WebElement branchName;

	@FindBy(css = "span[translate='entity.action.save']")
	WebElement staffSaveButton;

	public void createStaff(String staffNa, String branchNa) {
		CommonCode.waitTillElementDisplayed(driver, staffName);
		staffName.sendKeys(staffNa);
		CommonCode.selectFromDropDown(branchName, branchNa);
		CommonCode.clickElement(driver, staffSaveButton);
	}

	public void editStaff(String newName) {
		CommonCode.waitTillElementDisplayed(driver, staffName);
		staffName.clear();
		staffName.sendKeys(newName);
		CommonCode.clickElement(driver, staffSaveButton);
	}
}
