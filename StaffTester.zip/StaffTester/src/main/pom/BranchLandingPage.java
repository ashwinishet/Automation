
package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class BranchLandingPage extends BaseTest {

	BranchCreationPage branchCreationPage;

	public BranchLandingPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "span[translate='gurukulaApp.branch.home.createLabel']")
	WebElement createBranchButton;

	@FindBy(id = "searchQuery")
	WebElement branchSearch;

	@FindBy(css = "button[ng-click='search()']")
	WebElement branchSearchButton;

	@FindBy(css = "span[translate='entity.action.edit']")
	WebElement editButton;

	@FindBy(css = "span[translate='entity.action.view']")
	WebElement viewButton;

	@FindBy(css = "span[translate='entity.action.delete']")
	WebElement confirmDeleteButton;

	@FindBy(css = "table > tbody > tr > td:nth-child(4) > button.btn.btn-danger.btn-sm")
	WebElement deleteButton;

	public BranchCreationPage createBranchButtonClick() {
		CommonCode.clickElement(driver, createBranchButton);
		return new BranchCreationPage();
	}

	public void searchBranch(String searchText) {
		CommonCode.waitTillElementDisplayed(driver, branchSearch);
		branchSearch.clear();
		branchSearch.sendKeys(searchText);
		CommonCode.clickElement(driver, branchSearchButton);
	}

	public void editBranch(String newBranchNa, String newBranchID) {
		branchCreationPage = new BranchCreationPage();
		CommonCode.clickElement(driver, editButton);
		branchCreationPage.editBranch(newBranchNa, newBranchID);
	}

	public void deleteBranch() {
		CommonCode.clickElement(driver, deleteButton);
		CommonCode.clickElement(driver, confirmDeleteButton);
	}

	public BranchDetailsPage viewBranch() {
		CommonCode.clickElement(driver, viewButton);
		return new BranchDetailsPage();
	}
}
