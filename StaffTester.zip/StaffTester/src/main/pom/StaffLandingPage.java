package main.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import main.test.BaseTest;
import main.utility.CommonCode;

/**
 * @author Ashwini_Shet
 *
 */
public class StaffLandingPage extends BaseTest {
	public StaffLandingPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "button[data-target='#saveStaffModal']")
	WebElement createStaffButton;

	@FindBy(id = "searchQuery")
	WebElement staffSearch;

	@FindBy(css = "button[ng-click='search()']")
	WebElement staffSearchButton;

	@FindBy(css = "span[translate='entity.action.edit']")
	WebElement editButton;

	@FindBy(css = "span[translate='entity.action.view']")
	WebElement viewButton;

	@FindBy(css = "span[translate='entity.action.delete']")
	WebElement confirmDeleteButton;

	@FindBy(css = "table > tbody > tr > td:nth-child(4) > button.btn.btn-danger.btn-sm")
	WebElement deleteButton;

	@FindBy(css = "ul[class='pager'] li:nth-of-type(2)")
	WebElement previousPage;

	@FindBy(css = "ul[class='pager'] li:nth-of-type(3)")
	WebElement nextPage;

	@FindBy(css = "ul[class='pager'] li:nth-of-type(1)")
	WebElement firstPage;

	@FindBy(css = "ul[class='pager'] li:nth-of-type(41)")
	WebElement lastPage;

	@FindBy(css = "td:nth-child(3)")
	WebElement branchPlaceholder;

	@FindBy(css = "td:nth-child(2)")
	WebElement staffPlaceholder;

	@FindBy(css = "td:nth-child(1)")
	WebElement idPlaceholder;

	public void goToPreviousPage() {
		previousPage.click();
	}

	public void goToNextPage() {
		nextPage.click();
	}

	public void goToLastPage() {
		lastPage.click();
	}

	public void goToFirstPage() {
		firstPage.click();
	}

	public void searchStaff(String searchText) {
		CommonCode.waitTillElementDisplayed(driver, staffSearch);
		staffSearch.clear();
		staffSearch.sendKeys(searchText);
		CommonCode.clickElement(driver, staffSearchButton);
	}

	public void searchStaffwithValidation(String searchText) {
		CommonCode.waitTillElementDisplayed(driver, staffSearch);
		staffSearch.clear();
		staffSearch.sendKeys(searchText);
		CommonCode.clickElement(driver, staffSearchButton);
		boolean branchTextPresent = CommonCode.verifyTextPresentForWebElement(driver, branchPlaceholder);
		Assert.assertTrue(branchTextPresent);
		boolean staffTextPresent = CommonCode.verifyTextPresentForWebElement(driver, staffPlaceholder);
		Assert.assertTrue(staffTextPresent);
		boolean idTextPresent = CommonCode.verifyTextPresentForWebElement(driver, idPlaceholder);
		Assert.assertTrue(idTextPresent);
	}

	public StaffCreationPage createStaffButtonClick() {
		CommonCode.clickElement(driver, createStaffButton);
		return new StaffCreationPage();
	}

	public void editStaff(String staffName) {
		StaffCreationPage staffPage = new StaffCreationPage();
		CommonCode.clickElement(driver, editButton);
		staffPage.editStaff(staffName);
	}

	public void deleteStaff() {
		CommonCode.clickElement(driver, deleteButton);
		CommonCode.clickElement(driver, confirmDeleteButton);
	}

	public StaffDetailsPage viewStaff() {
		CommonCode.clickElement(driver, viewButton);
		return new StaffDetailsPage();
	}
}
